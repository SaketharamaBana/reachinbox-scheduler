import 'dotenv/config';

const int = (k: string, d: number) => Number(process.env[k] ?? d);
const str = (k: string, d = '') => process.env[k] ?? d;

export const config = {
  port: int('PORT', 4000),
  backendUrl: str('BACKEND_URL', 'http://localhost:4000'),
  frontendUrl: str('FRONTEND_URL', 'http://localhost:5173'),
  jwtSecret: str('JWT_SECRET', 'dev-secret'),
  databaseUrl: str('DATABASE_URL', 'postgres://postgres:postgres@localhost:5432/scheduler'),
  redisUrl: str('REDIS_URL', 'redis://localhost:6379'),
  esUrl: str('ELASTICSEARCH_URL', 'http://localhost:9200'),
  google: { clientId: str('GOOGLE_CLIENT_ID'), clientSecret: str('GOOGLE_CLIENT_SECRET') },
  slack: {
    clientId: str('SLACK_CLIENT_ID'),
    clientSecret: str('SLACK_CLIENT_SECRET'),
    redirectUri: str('SLACK_REDIRECT_URI'),
  },
  worker: {
    concurrency: int('WORKER_CONCURRENCY', 5),
    minDelayMs: int('MIN_DELAY_BETWEEN_EMAILS_MS', 2000),
  },
  maxEmailsPerHourPerSender: int('MAX_EMAILS_PER_HOUR_PER_SENDER', 50),
  senderCount: int('SENDER_COUNT', 3),
  embedWorker: str('EMBED_WORKER', 'true') !== 'false',
};
