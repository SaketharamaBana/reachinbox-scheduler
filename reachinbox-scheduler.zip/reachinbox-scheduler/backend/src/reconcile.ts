import { pool } from './db';
import { emailQueue, enqueueEmails } from './queue';

/** On boot: any DB email still pending but missing from Redis (e.g. Redis wiped) gets re-enqueued. */
export async function reconcileJobs() {
  const { rows } = await pool.query(
    `SELECT id, scheduled_at FROM emails
     WHERE status='scheduled' OR (status='processing' AND locked_at < now() - interval '2 minutes')`);
  let restored = 0;
  for (let i = 0; i < rows.length; i += 100) {
    const chunk = rows.slice(i, i + 100);
    const jobs = await Promise.all(chunk.map((r) => emailQueue.getJob(r.id)));
    const missing = chunk.filter((_, idx) => !jobs[idx]).map((r) => ({ id: r.id, scheduledAt: r.scheduled_at as Date }));
    await enqueueEmails(missing);
    restored += missing.length;
  }
  console.log(`Reconcile: ${rows.length} pending emails, ${restored} re-enqueued`);
}
