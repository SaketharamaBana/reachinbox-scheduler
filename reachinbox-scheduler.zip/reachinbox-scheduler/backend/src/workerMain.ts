import { initDb } from './db';
import { ensureSenders } from './mailer';
import { initSearch } from './search';
import { startWorker } from './worker';

(async () => { await initDb(); await ensureSenders(); await initSearch(); startWorker(); })();
