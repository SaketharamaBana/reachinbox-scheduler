import { Router } from 'express';
import jwt from 'jsonwebtoken';
import { ah, requireAuth, AuthedRequest } from './auth';
import { config } from './config';
import { pool } from './db';

export const slackRouter = Router();

// Browser navigates here -> redirect to Slack's real OAuth consent screen
slackRouter.get('/connect', requireAuth, (req, res) => {
  const state = jwt.sign({ uid: (req as AuthedRequest).userId }, config.jwtSecret, { expiresIn: '10m' });
  const q = new URLSearchParams({
    client_id: config.slack.clientId, scope: 'incoming-webhook', redirect_uri: config.slack.redirectUri, state,
  });
  res.redirect(`https://slack.com/oauth/v2/authorize?${q}`);
});

slackRouter.get('/callback', ah(async (req, res) => {
  try {
    const { uid } = jwt.verify(String(req.query.state), config.jwtSecret) as { uid: string };
    const r: any = await (await fetch('https://slack.com/api/oauth.v2.access', {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code: String(req.query.code), client_id: config.slack.clientId,
        client_secret: config.slack.clientSecret, redirect_uri: config.slack.redirectUri,
      }),
    })).json();
    if (!r.ok || !r.incoming_webhook?.url) throw new Error(r.error ?? 'no webhook');
    await pool.query(
      `INSERT INTO slack_connections (user_id, webhook_url, channel, team) VALUES ($1,$2,$3,$4)
       ON CONFLICT (user_id) DO UPDATE SET webhook_url=$2, channel=$3, team=$4, connected_at=now()`,
      [uid, r.incoming_webhook.url, r.incoming_webhook.channel, r.team?.name ?? null]);
    res.redirect(`${config.frontendUrl}/?slack=connected`);
  } catch { res.redirect(`${config.frontendUrl}/?slack=error`); }
}));

slackRouter.get('/status', requireAuth, ah(async (req, res) => {
  const { rows } = await pool.query('SELECT channel, team FROM slack_connections WHERE user_id=$1', [(req as AuthedRequest).userId]);
  res.json({ connected: !!rows[0], channel: rows[0]?.channel ?? null, team: rows[0]?.team ?? null });
}));

slackRouter.delete('/', requireAuth, ah(async (req, res) => {
  await pool.query('DELETE FROM slack_connections WHERE user_id=$1', [(req as AuthedRequest).userId]);
  res.json({ ok: true });
}));
