import { Client } from '@elastic/elasticsearch';
import { config } from './config';

const INDEX = 'emails';
export const es = new Client({ node: config.esUrl });

export interface EmailDoc {
  id: string; userId: string; toEmail: string; subject: string; body: string;
  status: string; scheduledAt: string; sentAt: string | null;
}

export async function initSearch() {
  try {
    if (!(await es.indices.exists({ index: INDEX }))) {
      await es.indices.create({
        index: INDEX,
        mappings: {
          properties: {
            userId: { type: 'keyword' }, status: { type: 'keyword' },
            toEmail: { type: 'text' }, subject: { type: 'text' }, body: { type: 'text' },
            scheduledAt: { type: 'date' }, sentAt: { type: 'date' },
          },
        },
      });
    }
  } catch (e) { console.warn('Elasticsearch unavailable:', (e as Error).message); }
}

// Search indexing must never break the send path, so every call swallows errors.
export async function indexEmails(docs: EmailDoc[]) {
  if (!docs.length) return;
  try {
    await es.bulk({ refresh: false, operations: docs.flatMap((d) => [{ index: { _index: INDEX, _id: d.id } }, d]) });
  } catch (e) { console.warn('ES index failed:', (e as Error).message); }
}

export async function searchEmails(userId: string, q: string) {
  const res = await es.search<EmailDoc>({
    index: INDEX, size: 50, sort: [{ scheduledAt: 'desc' }],
    query: {
      bool: {
        filter: [{ term: { userId } }],
        must: q ? [{ multi_match: { query: q, fields: ['toEmail', 'subject', 'body'], fuzziness: 'AUTO' } }] : [{ match_all: {} }],
      },
    },
  });
  return res.hits.hits.map((h) => h._source);
}
