import { redis } from './redis';

export const HOUR_MS = 3_600_000;
export const windowStart = (t = Date.now()) => Math.floor(t / HOUR_MS) * HOUR_MS;

// Atomic "increment if under limit". Runs in Redis so it is safe across workers/instances.
const CONSUME_LUA = `
local c = redis.call('INCR', KEYS[1])
if c == 1 then redis.call('EXPIRE', KEYS[1], ARGV[2]) end
if c > tonumber(ARGV[1]) then redis.call('DECR', KEYS[1]) return 0 end
return 1`;

export async function tryConsume(senderId: number, limit: number) {
  const window = windowStart();
  const ok = await redis.eval(CONSUME_LUA, 1, `rl:${senderId}:${window}`, limit, 7200);
  return { allowed: ok === 1, window };
}

/** Position (1-based) of this job in the overflow queue for the next window; keeps order stable. */
export async function overflowSlot(senderId: number, window: number) {
  const key = `rl:ovf:${senderId}:${window}`;
  const n = await redis.incr(key);
  await redis.expire(key, 7200);
  return n;
}

/** True only for the first limit hit per sender per window -> one Slack alert, not one per job. */
export async function firstHitInWindow(senderId: number, window: number) {
  return (await redis.set(`rl:notified:${senderId}:${window}`, '1', 'EX', 7200, 'NX')) === 'OK';
}
