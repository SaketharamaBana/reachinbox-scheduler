import { Queue } from 'bullmq';
import { redis } from './redis';

export const QUEUE_NAME = 'email-jobs';

export const emailQueue = new Queue<{ emailId: string }>(QUEUE_NAME, {
  connection: redis,
  defaultJobOptions: { attempts: 1, removeOnComplete: 2000, removeOnFail: 5000 },
});

/** Enqueue delayed jobs. jobId === emailId, so re-adding the same email is a no-op (idempotent). */
export async function enqueueEmails(items: { id: string; scheduledAt: Date }[]) {
  const CHUNK = 500;
  for (let i = 0; i < items.length; i += CHUNK) {
    await emailQueue.addBulk(
      items.slice(i, i + CHUNK).map((e) => ({
        name: 'send',
        data: { emailId: e.id },
        opts: { jobId: e.id, delay: Math.max(0, e.scheduledAt.getTime() - Date.now()) },
      })),
    );
  }
}
