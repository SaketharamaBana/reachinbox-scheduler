import nodemailer, { Transporter } from 'nodemailer';
import { pool } from './db';
import { config } from './config';

export interface Sender { id: number; email: string; smtp_user: string; smtp_pass: string; host: string; port: number }

const transports = new Map<number, Transporter>();

/** Creates Ethereal test accounts on first boot (persisted in DB, reused after restarts). */
export async function ensureSenders() {
  const { rows } = await pool.query('SELECT count(*)::int AS n FROM senders');
  for (let i = rows[0].n; i < config.senderCount; i++) {
    const a = await nodemailer.createTestAccount();
    await pool.query(
      'INSERT INTO senders (email, smtp_user, smtp_pass, host, port) VALUES ($1,$2,$3,$4,$5)',
      [a.user, a.user, a.pass, a.smtp.host, a.smtp.port],
    );
    console.log(`Created Ethereal sender ${a.user}`);
  }
}

export async function listSenderIds(): Promise<number[]> {
  const { rows } = await pool.query('SELECT id FROM senders ORDER BY id');
  return rows.map((r) => r.id);
}

async function getTransport(senderId: number) {
  let t = transports.get(senderId);
  if (!t) {
    const { rows } = await pool.query<Sender>('SELECT * FROM senders WHERE id=$1', [senderId]);
    const s = rows[0];
    t = nodemailer.createTransport({ host: s.host, port: s.port, secure: false, auth: { user: s.smtp_user, pass: s.smtp_pass } });
    transports.set(senderId, t);
  }
  return t;
}

export async function sendMail(senderId: number, to: string, subject: string, text: string) {
  const t = await getTransport(senderId);
  const { rows } = await pool.query<Sender>('SELECT email FROM senders WHERE id=$1', [senderId]);
  const info = await t.sendMail({ from: rows[0].email, to, subject, text });
  return { previewUrl: (nodemailer.getTestMessageUrl(info) || null) as string | null };
}
