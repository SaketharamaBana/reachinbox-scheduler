import { pool } from './db';

export async function notifyRateLimit(userId: string, senderEmail: string, limit: number, resumeAt: Date) {
  try {
    const { rows } = await pool.query('SELECT webhook_url FROM slack_connections WHERE user_id=$1', [userId]);
    if (!rows[0]) return; // Slack not connected: silently skip
    const res = await fetch(rows[0].webhook_url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: `:warning: Hourly limit reached for sender *${senderEmail}* (${limit}/hour). Remaining emails were rescheduled to resume at ${resumeAt.toISOString()}.`,
      }),
    });
    if (!res.ok) console.warn('Slack webhook responded', res.status);
  } catch (e) { console.warn('Slack notify failed:', (e as Error).message); }
}
