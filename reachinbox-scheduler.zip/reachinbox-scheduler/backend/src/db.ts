import { Pool } from 'pg';
import { config } from './config';

export const pool = new Pool({ connectionString: config.databaseUrl });

export async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY, email TEXT NOT NULL, name TEXT NOT NULL, avatar TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS senders (
      id SERIAL PRIMARY KEY, email TEXT NOT NULL, smtp_user TEXT NOT NULL, smtp_pass TEXT NOT NULL,
      host TEXT NOT NULL, port INT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS emails (
      id UUID PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id),
      sender_id INT NOT NULL REFERENCES senders(id),
      to_email TEXT NOT NULL,
      subject TEXT NOT NULL,
      body TEXT NOT NULL,
      scheduled_at TIMESTAMPTZ NOT NULL,
      status TEXT NOT NULL DEFAULT 'scheduled',   -- scheduled | processing | sent | failed
      hourly_limit INT,
      reschedules INT NOT NULL DEFAULT 0,
      locked_at TIMESTAMPTZ,
      sent_at TIMESTAMPTZ,
      preview_url TEXT,
      error TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    CREATE INDEX IF NOT EXISTS emails_user_status_idx ON emails (user_id, status, scheduled_at);
    CREATE TABLE IF NOT EXISTS slack_connections (
      user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      webhook_url TEXT NOT NULL, channel TEXT, team TEXT,
      connected_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `);
}
