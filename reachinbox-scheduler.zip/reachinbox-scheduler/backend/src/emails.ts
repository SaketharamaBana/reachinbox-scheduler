import { Router } from 'express';
import { randomUUID } from 'crypto';
import { ah, requireAuth, AuthedRequest } from './auth';
import { pool } from './db';
import { enqueueEmails } from './queue';
import { listSenderIds } from './mailer';
import { indexEmails, searchEmails } from './search';

export const emailsRouter = Router();
emailsRouter.use(requireAuth);

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

emailsRouter.post('/schedule', ah(async (req, res) => {
  const { userId } = req as AuthedRequest;
  const { subject, body, recipients, startTime, delaySeconds = 0, hourlyLimit } = req.body ?? {};
  const start = new Date(startTime);
  const list: string[] = Array.isArray(recipients) ? [...new Set<string>(recipients.map((r: string) => String(r).trim().toLowerCase()))].filter((r) => EMAIL_RE.test(r)) : [];

  if (!subject || !body) return res.status(400).json({ error: 'Subject and body are required' });
  if (!list.length) return res.status(400).json({ error: 'At least one valid recipient is required' });
  if (list.length > 50000) return res.status(400).json({ error: 'Too many recipients (max 50,000)' });
  if (isNaN(start.getTime())) return res.status(400).json({ error: 'Invalid start time' });
  if (!(Number(delaySeconds) >= 0)) return res.status(400).json({ error: 'Delay must be >= 0' });
  if (hourlyLimit != null && !(Number.isInteger(hourlyLimit) && hourlyLimit > 0)) return res.status(400).json({ error: 'Hourly limit must be a positive integer' });

  const senders = await listSenderIds();
  const now = Date.now();
  const items = list.map((to, i) => ({
    id: randomUUID(), senderId: senders[i % senders.length], to, // round-robin across senders
    at: new Date(Math.max(start.getTime(), now) + i * Number(delaySeconds) * 1000),
  }));

  await pool.query(
    `INSERT INTO emails (id,user_id,sender_id,to_email,subject,body,scheduled_at,hourly_limit)
     SELECT u.id,$1,u.sender_id,u.to_email,$2,$3,u.at,$4
     FROM UNNEST($5::uuid[],$6::int[],$7::text[],$8::timestamptz[]) AS u(id,sender_id,to_email,at)`,
    [userId, subject, body, hourlyLimit ?? null, items.map((i) => i.id), items.map((i) => i.senderId), items.map((i) => i.to), items.map((i) => i.at.toISOString())]);

  await enqueueEmails(items.map((i) => ({ id: i.id, scheduledAt: i.at })));
  await indexEmails(items.map((i) => ({
    id: i.id, userId, toEmail: i.to, subject, body, status: 'scheduled', scheduledAt: i.at.toISOString(), sentAt: null,
  })));
  res.status(201).json({ scheduled: items.length, firstAt: items[0].at, lastAt: items[items.length - 1].at });
}));

emailsRouter.get('/', ah(async (req, res) => {
  const { userId } = req as AuthedRequest;
  const sent = req.query.status === 'sent';
  const limit = Math.min(Number(req.query.limit) || 200, 500);
  const { rows } = await pool.query(
    `SELECT id, to_email AS "toEmail", subject, status, scheduled_at AS "scheduledAt",
            sent_at AS "sentAt", preview_url AS "previewUrl", error
     FROM emails WHERE user_id=$1 AND status = ANY($2)
     ORDER BY ${sent ? 'sent_at DESC' : 'scheduled_at ASC'} LIMIT $3`,
    [userId, sent ? ['sent', 'failed'] : ['scheduled', 'processing'], limit]);
  res.json(rows);
}));

emailsRouter.get('/search', ah(async (req, res) => {
  try { res.json(await searchEmails((req as AuthedRequest).userId, String(req.query.q ?? ''))); }
  catch { res.status(503).json({ error: 'Search is unavailable' }); }
}));
