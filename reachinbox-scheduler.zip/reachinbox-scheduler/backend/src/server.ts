import express, { NextFunction, Request, Response } from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { createBullBoard } from '@bull-board/api';
import { BullMQAdapter } from '@bull-board/api/bullMQAdapter';
import { ExpressAdapter } from '@bull-board/express';
import { config } from './config';
import { initDb } from './db';
import { emailQueue } from './queue';
import { ensureSenders } from './mailer';
import { initSearch } from './search';
import { startWorker } from './worker';
import { reconcileJobs } from './reconcile';
import { authRouter } from './auth';
import { emailsRouter } from './emails';
import { slackRouter } from './slackRoutes';

async function main() {
  await initDb();
  await ensureSenders();
  await initSearch();
  await reconcileJobs();

  const app = express();
  app.use(cors({ origin: config.frontendUrl, credentials: true }));
  app.use(express.json({ limit: '10mb' }));
  app.use(cookieParser());

  // Live BullMQ dashboard
  const board = new ExpressAdapter();
  board.setBasePath('/admin/queues');
  createBullBoard({ queues: [new BullMQAdapter(emailQueue) as any], serverAdapter: board });
  app.use('/admin/queues', board.getRouter());

  app.get('/health', (_req, res) => res.json({ ok: true }));
  app.use('/api/auth', authRouter);
  app.use('/api/emails', emailsRouter);
  app.use('/api/slack', slackRouter);

  app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  });

  if (config.embedWorker) startWorker();
  app.listen(config.port, () => console.log(`API on :${config.port}  |  BullMQ dashboard: ${config.backendUrl}/admin/queues`));
}

main().catch((e) => { console.error(e); process.exit(1); });
