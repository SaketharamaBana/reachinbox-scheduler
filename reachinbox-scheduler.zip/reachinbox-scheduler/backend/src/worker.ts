import { Worker, DelayedError } from 'bullmq';
import { redis } from './redis';
import { pool } from './db';
import { config } from './config';
import { QUEUE_NAME } from './queue';
import { HOUR_MS, tryConsume, overflowSlot, firstHitInWindow } from './rateLimiter';
import { sendMail } from './mailer';
import { indexEmails } from './search';
import { notifyRateLimit } from './slack';

async function reindex(id: string) {
  const { rows } = await pool.query(
    `SELECT id, user_id AS "userId", to_email AS "toEmail", subject, body, status,
            scheduled_at AS "scheduledAt", sent_at AS "sentAt" FROM emails WHERE id=$1`, [id]);
  if (rows[0]) await indexEmails([rows[0]]);
}

export function startWorker() {
  const worker = new Worker<{ emailId: string }>(
    QUEUE_NAME,
    async (job, token) => {
      // 1) Idempotent claim: only one worker can flip scheduled -> processing.
      //    A stale 'processing' row (worker crashed mid-send) can be re-claimed after 2 min.
      const claim = await pool.query(
        `UPDATE emails SET status='processing', locked_at=now()
         WHERE id=$1 AND (status='scheduled' OR (status='processing' AND locked_at < now() - interval '2 minutes'))
         RETURNING *`, [job.data.emailId]);
      const email = claim.rows[0];
      if (!email) return { skipped: true }; // already sent / failed / claimed elsewhere

      // 2) Hourly rate limit (Redis atomic counter per sender per hour window)
      const limit: number = email.hourly_limit ?? config.maxEmailsPerHourPerSender;
      const { allowed, window } = await tryConsume(email.sender_id, limit);
      if (!allowed) {
        const slot = await overflowSlot(email.sender_id, window);
        const resumeAt = window + HOUR_MS + (slot - 1) * config.worker.minDelayMs; // arrival order preserved
        await pool.query(
          `UPDATE emails SET status='scheduled', scheduled_at=$2, reschedules=reschedules+1, locked_at=NULL WHERE id=$1`,
          [email.id, new Date(resumeAt)]);
        await reindex(email.id);
        if (await firstHitInWindow(email.sender_id, window)) {
          const s = await pool.query('SELECT email FROM senders WHERE id=$1', [email.sender_id]);
          await notifyRateLimit(email.user_id, s.rows[0].email, limit, new Date(window + HOUR_MS));
        }
        await job.moveToDelayed(resumeAt, token); // not dropped, not failed: pushed to next window
        throw new DelayedError();
      }

      // 3) Send
      try {
        const { previewUrl } = await sendMail(email.sender_id, email.to_email, email.subject, email.body);
        await pool.query(`UPDATE emails SET status='sent', sent_at=now(), preview_url=$2, locked_at=NULL WHERE id=$1`, [email.id, previewUrl]);
      } catch (e) {
        await pool.query(`UPDATE emails SET status='failed', sent_at=now(), error=$2, locked_at=NULL WHERE id=$1`, [email.id, (e as Error).message]);
      }
      await reindex(email.id);
      return { sent: true };
    },
    {
      connection: redis,
      concurrency: config.worker.concurrency,
      // Queue-wide (shared by all workers): at most 1 job per minDelayMs => min delay between sends
      limiter: { max: 1, duration: config.worker.minDelayMs },
    },
  );
  worker.on('failed', (job, err) => console.error(`job ${job?.id} failed:`, err.message));
  console.log(`Worker started (concurrency=${config.worker.concurrency}, minDelay=${config.worker.minDelayMs}ms)`);
  return worker;
}
