import { Router, Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { config } from './config';
import { pool } from './db';

export interface AuthedRequest extends Request { userId: string }

export const ah = (fn: (req: any, res: Response, next: NextFunction) => Promise<unknown>) =>
  (req: Request, res: Response, next: NextFunction) => fn(req, res, next).catch(next);

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  try {
    const p = jwt.verify(req.cookies?.token ?? '', config.jwtSecret) as { uid: string };
    (req as AuthedRequest).userId = p.uid;
    next();
  } catch { res.status(401).json({ error: 'Not authenticated' }); }
}

const redirectUri = `${config.backendUrl}/api/auth/google/callback`;
export const authRouter = Router();

authRouter.get('/google', (_req, res) => {
  const q = new URLSearchParams({
    client_id: config.google.clientId, redirect_uri: redirectUri, response_type: 'code',
    scope: 'openid email profile', access_type: 'online', prompt: 'select_account',
  });
  res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${q}`);
});

authRouter.get('/google/callback', ah(async (req, res) => {
  const code = String(req.query.code ?? '');
  if (!code) return res.redirect(`${config.frontendUrl}/?error=oauth`);
  const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code, client_id: config.google.clientId, client_secret: config.google.clientSecret,
      redirect_uri: redirectUri, grant_type: 'authorization_code',
    }),
  });
  const tok: any = await tokenRes.json();
  if (!tok.access_token) return res.redirect(`${config.frontendUrl}/?error=oauth`);
  const u: any = await (await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
    headers: { Authorization: `Bearer ${tok.access_token}` },
  })).json();
  await pool.query(
    `INSERT INTO users (id,email,name,avatar) VALUES ($1,$2,$3,$4)
     ON CONFLICT (id) DO UPDATE SET email=$2, name=$3, avatar=$4`,
    [u.sub, u.email, u.name ?? u.email, u.picture ?? null]);
  const token = jwt.sign({ uid: u.sub }, config.jwtSecret, { expiresIn: '7d' });
  res.cookie('token', token, { httpOnly: true, sameSite: 'lax', maxAge: 7 * 864e5 });
  res.redirect(config.frontendUrl);
}));

authRouter.get('/me', requireAuth, ah(async (req, res) => {
  const { rows } = await pool.query('SELECT id,email,name,avatar FROM users WHERE id=$1', [(req as AuthedRequest).userId]);
  rows[0] ? res.json(rows[0]) : res.status(401).json({ error: 'Not authenticated' });
}));

authRouter.post('/logout', (_req, res) => { res.clearCookie('token'); res.json({ ok: true }); });
