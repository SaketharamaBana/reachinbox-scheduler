import { useState } from 'react';
import { Header } from '../components/Header';
import { EmailsTable } from '../components/EmailsTable';
import { ComposeModal } from '../components/ComposeModal';
import { SlackConnect } from '../components/SlackConnect';
import { Button } from '../components/ui';
import { useEmails } from '../hooks/useEmails';
import type { Tab, User } from '../types';

const TABS: { id: Tab; label: string }[] = [
  { id: 'scheduled', label: 'Scheduled Emails' },
  { id: 'sent', label: 'Sent Emails' },
];

export default function Dashboard({ user, onLogout }: { user: User; onLogout: () => void }) {
  const [tab, setTab] = useState<Tab>('scheduled');
  const [composing, setComposing] = useState(false);
  const { items, loading, error, reload } = useEmails(tab);

  return (
    <>
      <Header user={user} onLogout={onLogout} />
      <main className="mx-auto max-w-6xl px-4 py-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex gap-1 rounded-lg bg-slate-200/60 p-1">
            {TABS.map((t) => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`rounded-md px-4 py-1.5 text-sm font-medium ${tab === t.id ? 'bg-white shadow-sm' : 'text-slate-600'}`}>{t.label}</button>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <SlackConnect />
            <Button onClick={() => setComposing(true)}>Compose new email</Button>
          </div>
        </div>
        <div className="rounded-xl bg-white ring-1 ring-slate-200">
          <EmailsTable tab={tab} items={items} loading={loading} error={error} />
        </div>
      </main>
      {composing && <ComposeModal onClose={() => setComposing(false)} onScheduled={reload} />}
    </>
  );
}
