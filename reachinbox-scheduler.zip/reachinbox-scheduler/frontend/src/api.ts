import type { EmailItem, ScheduleInput, SlackStatus, Tab, User } from './types';

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  const r = await fetch(path, { credentials: 'include', headers: { 'Content-Type': 'application/json' }, ...init });
  if (!r.ok) {
    const b = await r.json().catch(() => ({}));
    throw new Error(b.error || r.statusText);
  }
  return r.json();
}

export const api = {
  me: () => req<User>('/api/auth/me'),
  logout: () => req<{ ok: boolean }>('/api/auth/logout', { method: 'POST' }),
  list: (tab: Tab) => req<EmailItem[]>(`/api/emails?status=${tab}`),
  schedule: (data: ScheduleInput) =>
    req<{ scheduled: number }>('/api/emails/schedule', { method: 'POST', body: JSON.stringify(data) }),
  slackStatus: () => req<SlackStatus>('/api/slack/status'),
  slackDisconnect: () => req<{ ok: boolean }>('/api/slack', { method: 'DELETE' }),
};
