import { ChangeEvent, FormEvent, useState } from 'react';
import { api } from '../api';
import { extractEmails } from '../lib/csv';
import { Button, Field, Input, Modal, Textarea } from './ui';
import { useToast } from './Toast';

const toLocalInput = (d: Date) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);

export function ComposeModal({ onClose, onScheduled }: { onClose: () => void; onScheduled: () => void }) {
  const toast = useToast();
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [recipients, setRecipients] = useState<string[]>([]);
  const [fileName, setFileName] = useState('');
  const [startTime, setStartTime] = useState(toLocalInput(new Date(Date.now() + 60_000)));
  const [delaySeconds, setDelay] = useState(2);
  const [hourlyLimit, setLimit] = useState(50);
  const [busy, setBusy] = useState(false);

  const onFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFileName(f.name);
    setRecipients(extractEmails(await f.text()));
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!recipients.length) return toast('error', 'Upload a CSV or text file that contains email addresses.');
    setBusy(true);
    try {
      const r = await api.schedule({ subject, body, recipients, startTime: new Date(startTime).toISOString(), delaySeconds, hourlyLimit });
      toast('success', `Scheduled ${r.scheduled} emails`);
      onScheduled();
      onClose();
    } catch (err) { toast('error', (err as Error).message); }
    finally { setBusy(false); }
  };

  return (
    <Modal title="Compose new email" onClose={onClose}>
      <form onSubmit={submit} className="space-y-4">
        <Field label="Subject"><Input required value={subject} onChange={(e) => setSubject(e.target.value)} /></Field>
        <Field label="Body"><Textarea required rows={5} value={body} onChange={(e) => setBody(e.target.value)} /></Field>
        <Field label="Leads file (CSV or text)" hint={recipients.length ? `${fileName}: ${recipients.length} email addresses detected` : 'Any file containing email addresses'}>
          <input type="file" accept=".csv,.txt,text/csv,text/plain" onChange={onFile} className="block w-full text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-brand-soft file:px-3 file:py-2 file:text-sm file:font-medium file:text-brand-dark" />
        </Field>
        <Field label="Start time"><Input type="datetime-local" required value={startTime} onChange={(e) => setStartTime(e.target.value)} /></Field>
        <div className="grid grid-cols-2 gap-4">
          <Field label="Delay between emails (seconds)"><Input type="number" min={0} required value={delaySeconds} onChange={(e) => setDelay(Number(e.target.value))} /></Field>
          <Field label="Hourly limit (per sender)"><Input type="number" min={1} required value={hourlyLimit} onChange={(e) => setLimit(Number(e.target.value))} /></Field>
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
          <Button type="submit" disabled={busy}>{busy ? 'Scheduling…' : 'Schedule'}</Button>
        </div>
      </form>
    </Modal>
  );
}
