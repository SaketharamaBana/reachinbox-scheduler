import { useEffect, useState } from 'react';
import { api } from '../api';
import { Button } from './ui';
import { useToast } from './Toast';
import type { SlackStatus } from '../types';

export function SlackConnect() {
  const toast = useToast();
  const [s, setS] = useState<SlackStatus | null>(null);
  const refresh = () => api.slackStatus().then(setS).catch(() => setS(null));

  useEffect(() => {
    refresh();
    const flag = new URLSearchParams(location.search).get('slack');
    if (flag) {
      toast(flag === 'connected' ? 'success' : 'error', flag === 'connected' ? 'Slack connected' : "Couldn't connect Slack. Try again.");
      history.replaceState({}, '', '/');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!s) return null;
  if (!s.connected) return <Button variant="ghost" onClick={() => (location.href = '/api/slack/connect')}>Connect Slack</Button>;
  return (
    <div className="flex items-center gap-2 text-sm text-slate-600">
      <span>Slack: {s.channel ?? 'connected'}</span>
      <Button variant="ghost" onClick={async () => { await api.slackDisconnect(); refresh(); toast('success', 'Slack disconnected'); }}>Disconnect</Button>
    </div>
  );
}
