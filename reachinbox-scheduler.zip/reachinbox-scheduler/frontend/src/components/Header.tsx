import { Button } from './ui';
import type { User } from '../types';

export function Header({ user, onLogout }: { user: User; onLogout: () => void }) {
  return (
    <header className="border-b border-slate-200 bg-white">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <span className="text-lg font-bold">ReachInbox <span className="font-normal text-slate-400">Scheduler</span></span>
        <div className="flex items-center gap-3">
          {user.avatar
            ? <img src={user.avatar} alt="" referrerPolicy="no-referrer" className="h-9 w-9 rounded-full" />
            : <div className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-soft font-semibold text-brand-dark">{user.name[0]}</div>}
          <div className="hidden text-right leading-tight sm:block">
            <div className="text-sm font-medium">{user.name}</div>
            <div className="text-xs text-slate-500">{user.email}</div>
          </div>
          <Button variant="ghost" onClick={onLogout}>Log out</Button>
        </div>
      </div>
    </header>
  );
}
