import { Spinner, StatusBadge } from './ui';
import { fmtDate } from '../lib/format';
import type { EmailItem, Tab } from '../types';

interface Props { tab: Tab; items: EmailItem[]; loading: boolean; error: string | null }

export function EmailsTable({ tab, items, loading, error }: Props) {
  if (loading) return <div className="flex justify-center py-20"><Spinner /></div>;
  if (error) return <p className="py-20 text-center text-sm text-red-600">Couldn't load emails: {error}</p>;
  if (!items.length)
    return (
      <div className="py-20 text-center text-slate-500">
        <p className="font-medium text-slate-700">{tab === 'scheduled' ? 'No scheduled emails' : 'No sent emails yet'}</p>
        <p className="mt-1 text-sm">{tab === 'scheduled' ? 'Choose Compose new email to schedule your first campaign.' : 'Emails appear here once they have been sent.'}</p>
      </div>
    );
  const timeLabel = tab === 'scheduled' ? 'Scheduled time' : 'Sent time';
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead className="border-b border-slate-200 text-slate-500">
          <tr>{['Email', 'Subject', timeLabel, 'Status'].map((h) => <th key={h} className="px-4 py-3 font-medium">{h}</th>)}</tr>
        </thead>
        <tbody>
          {items.map((e) => (
            <tr key={e.id} className="border-b border-slate-100 hover:bg-slate-50">
              <td className="px-4 py-3">
                {e.previewUrl ? <a href={e.previewUrl} target="_blank" rel="noreferrer" className="text-brand-dark underline">{e.toEmail}</a> : e.toEmail}
              </td>
              <td className="max-w-xs truncate px-4 py-3">{e.subject}</td>
              <td className="whitespace-nowrap px-4 py-3">{fmtDate(tab === 'scheduled' ? e.scheduledAt : e.sentAt)}</td>
              <td className="px-4 py-3" title={e.error ?? undefined}><StatusBadge status={e.status} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
