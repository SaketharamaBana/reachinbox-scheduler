import { useCallback, useEffect, useState } from 'react';
import { api } from '../api';
import type { EmailItem, Tab } from '../types';

/** Loads a tab's emails and polls every 5s so status changes appear live. */
export function useEmails(tab: Tab) {
  const [items, setItems] = useState<EmailItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try { setItems(await api.list(tab)); setError(null); }
    catch (e) { setError((e as Error).message); }
    finally { setLoading(false); }
  }, [tab]);

  useEffect(() => {
    setLoading(true);
    load();
    const t = setInterval(load, 5000);
    return () => clearInterval(t);
  }, [load]);

  return { items, loading, error, reload: load };
}
