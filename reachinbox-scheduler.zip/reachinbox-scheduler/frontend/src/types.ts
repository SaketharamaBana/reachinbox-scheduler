export interface User { id: string; email: string; name: string; avatar: string | null }
export type EmailStatus = 'scheduled' | 'processing' | 'sent' | 'failed';
export type Tab = 'scheduled' | 'sent';
export interface EmailItem {
  id: string; toEmail: string; subject: string; status: EmailStatus;
  scheduledAt: string; sentAt: string | null; previewUrl: string | null; error: string | null;
}
export interface ScheduleInput {
  subject: string; body: string; recipients: string[]; startTime: string; delaySeconds: number; hourlyLimit: number;
}
export interface SlackStatus { connected: boolean; channel: string | null; team: string | null }
