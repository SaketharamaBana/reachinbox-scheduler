const EMAIL_RE = /[^\s@,;"'<>]+@[^\s@,;"'<>]+\.[^\s@,;"'<>]+/g;

/** Extract unique, lower-cased email addresses from any CSV/text content. */
export function extractEmails(text: string): string[] {
  return [...new Set((text.match(EMAIL_RE) ?? []).map((e) => e.toLowerCase()))];
}
