import { useEffect, useState } from 'react';
import { api } from './api';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import { Spinner } from './components/ui';
import type { User } from './types';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    api.me().then(setUser).catch(() => setUser(null)).finally(() => setChecking(false));
  }, []);

  if (checking) return <div className="flex min-h-screen items-center justify-center"><Spinner /></div>;
  if (!user) return <Login />;
  return <Dashboard user={user} onLogout={async () => { await api.logout(); setUser(null); }} />;
}
